package net.sf.jxls.tag;

import java.util.Map;

/**
 * @author Leonid Vysochyn
 */
public interface TagLib {
    public Map getTags();
}
