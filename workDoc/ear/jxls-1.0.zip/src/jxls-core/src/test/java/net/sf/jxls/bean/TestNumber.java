package net.sf.jxls.bean;

/**
 * @author Leonid Vysochyn
 *         Date: 12.03.2009
 */
public class TestNumber {
    int testNumber;

    public TestNumber(int testNumber) {
        this.testNumber = testNumber;
    }

    public int getTestNumber() {
        return testNumber;
    }

    public void setTestNumber(int testNumber) {
        this.testNumber = testNumber;
    }
}
